<?php
/*
Plugin Name: WriteToThem.com
Plugin URI: http://www.memespring.co.uk
Description: Write to your MP, Councillors, MEP,  LAM, MSP, WAM
 
Version: 1.0
License: GPL
Author: Richard Pope - mySociety volunteer
Author URI:http://www.memespring.co.uk
*/


if (is_plugin_page()) { 
	
	//Saving etc
	 if (isset($_POST['save_writetothem_settings'])) {
       $option_contacttype = $_POST['contacttype'];
       $option_contacttitle = $_POST['contacttitle'];
       update_option('writetothem_contacttype', $option_contacttype);
       update_option('writetothem_contacttitle', $option_contacttitle);
       ?> <div class="updated"><p>All saved : )</p></div> <?php
     }
	
	?> 
    <div class="wrap" style="position:relative;">   
    <p style="text-align:right; position:absolute; right:1em; top:1px; border:solid 13px white;"><a href="http://www.mysociety.org"  style="border:none!important;"><img src="http://www.placeopedia.com/images/mysociety.png" alt="mySociety" /></a></p>
    <h2>WriteToThem.com</h2>
    
	<form method="post">
			
            <fieldset class="options">
				<h4>Display a box that lets people enter their postcode to contact their elected representatives</h4>
            	<table>
					<tr>
            			<td>
            				<label for="contacttype">Who would you like people to contact?</label>
            			</td>
            			<td>
	            			<select id="contacttype" name="contacttype">
		    					<option <?php if(get_option('writetothem_contacttype') == '') { echo 'selected="selected"'; } ?> value="">The lot of them (Councillors, MP, MEPs, MSPs, or Welsh and London Assembly Member)</option>
		    					<option <?php if(get_option('writetothem_contacttype') == 'westminstermp') { echo 'selected="selected"'; } ?> value="westminstermp">Westminster MP</option>
								<option <?php if(get_option('writetothem_contacttype') == 'council') { echo 'selected="selected"'; } ?> value="council ">Councillors</option>
								<option <?php if(get_option('writetothem_contacttype') == 'regionalmp') { echo 'selected="regionalmp"'; } ?> value="regionalmp">Regional MP (Scottish Parliament, Welsh Assembly, Northern Ireland Assembly, or London Assembly) </option>
								<option <?php if(get_option('writetothem_contacttype') == 'mep') { echo 'selected="selected"'; } ?> value="mep ">Members of European Parliament</option>
		    				</select>
            			</td>
            		</tr>
            		<tr>
            			<td>
            				<label for="Title">Give the contact box a title (leave this blank if you don't want a title)</label>
            			</td>
            			<td>
            				<input name="contacttitle" type="text" id="contacttitle" value="<?php echo get_option('writetothem_contacttitle'); ?>" size="30" /> 
    						<em>e.g. "Contact your councillors"</em>
            			</td>
            		</tr>
            	</table>
            </fieldset>
				
	  <div class="submit"> 
            <input type="submit" name="save_writetothem_settings" value="<?php _e('Save', 'save_writetothem_settings') ?>" style="font-weight:bold;" /></div>
    </p></form>
    
    <h3>Techy instructions</h3>
    <p>Add the following to one of your templates</p>
    <code>&lt;?php getWriteToThemForm(); ?&gt;</code>
    
</div>
<?php }else{
	
	function getWriteToThemForm (){
		
		//get the settings
		$settings_title = trim(get_option('writetothem_contacttitle'));
		$settings_contacttype = trim(get_option('writetothem_contacttype'));
		
		$form_text = "
			<div class=\"writetothem\">
				<h3>{$settings_title}</h3>
				<div>
					<form method=\"get\" action=\"http://www.writetothem.com/\">
						<input type=\"hidden\" name=\"a\" value=\"{$settings_contacttype}\">
				            <div style=\"margin-bottom:0.5em;\"><label for=\"text\">Enter your postcode</label></div>
				            <div><input type=\"text\" name=\"pc\" size=\"13\">
				            <input type=\"submit\" value=\"Go\"></div>
				    </form>
				</div>
			</div>
		";
		/*
		// build up the form
		$form_text = '';	
		$form_text .= '<form accept-charset="utf-8" name="pledge" method="post" action="http://www.pledgebank.com/new">';
		$form_text .= '<table  style="padding:none; margin:none;">';
		$form_text .= '<tr><td>';
		$form_text .= '<label for="title"><strong>I will</strong></label><br/>';
		$form_text .= '<textarea title="Pledge" name="title" id="txtTitle"rows="3" cols="40">' . $settings_text .'</textarea>';
		$form_text .= '</td></tr>';
		$form_text .= '<tr><td>';
		$form_text .= '<label for="target"><strong>but only if</strong>&nbsp;&nbsp;</label>';
		$form_text .= '<input title="Target number of people" size="5" type="text" id="txtTarget" name="target" value="' . $settings_target . '">';
		$form_text .= '<input type="hidden" id="hidType" name="type" value="other people">';
		$form_text .= '<strong>&nbsp;other people</strong>';
		$form_text .= '</td></tr>';
		$form_text .= '<tr><td>';
		$form_text .= '<label for="signup"><strong>will</strong>&nbsp;&nbsp;</label>';
		$form_text .= '<input type="text" id="txtSignup" name="signup" size="40" value="' . $settings_instructions . '">';
		$form_text .= '<input type="hidden" name="date" value="">';
		$form_text .= '<input type="hidden" name="ref" value=""> ';
		$form_text .= '<input type="hidden" name="detail" value="" />';
		$form_text .= '<input type="hidden" name="name" value="">';
		$form_text .= '<input type="hidden" name="email" value="">';
		$form_text .= '<input type="hidden" name="identity" value="">';
		$form_text .= '</td></tr>';
		$form_text .= '</table>';
		$form_text .= '<br/>';
		$form_text .= '<input id="btnPledgeContinue" class="button" type="submit" name="tostep1" value="Continue on Pledgebank.com &gt;&gt;">';
		$form_text .= '</form>';
		*/
		//Print the form
		print $form_text;
		
	} 
	
	//Suport functions
	function getRssUrl($keywords = ''){
		
		$rss_url = '';
		
		//build up the url
		$rss_url = 'http://gb.en-gb.pledgebank.com/rss/search?q=' . urlencode($keywords);
		
		return $rss_url; 
	}
	
	//Menus etc
	function wtt_admin_menu() {
	    $pagefile = basename(__FILE__);
	        add_options_page('WriteToThem Options Page', 'WriteToThem.com', 8, $pagefile);
	        }
	        
	add_action('admin_menu', 'wtt_admin_menu');
}


?>